import streamlit as st
import pickle

# Load model and vectorizer
model = pickle.load(open("model.pkl", "rb"))
vectorizer = pickle.load(open("vectorizer.pkl", "rb"))

st.title("🕵️ Fake Review Detector")

input_text = st.text_area("Enter a review to check:")

if st.button("Analyze"):
    vec = vectorizer.transform([input_text])
    result = model.predict(vec)[0]
    st.success("✅ Genuine Review" if result == 0 else "🟥 Fake Review")
