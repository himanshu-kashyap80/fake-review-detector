import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import classification_report
import pickle

# Load dataset directly
url = "https://raw.githubusercontent.com/SayamAlt/Fake-Reviews-Detection/main/fake%20reviews%20dataset.csv"
df = pd.read_csv(url)

# Prepare features and labels
X = df['text_']  # use correct column for review text
y = df['label'].map({'OR': 0, 'CG': 1})  # 0 = real, 1 = fake

# Vectorize text
tfidf = TfidfVectorizer(stop_words='english', max_df=0.7)
X_vec = tfidf.fit_transform(X)

# Train/test split
X_train, X_test, y_train, y_test = train_test_split(X_vec, y, test_size=0.2, random_state=42)

# Train model
model = MultinomialNB()
model.fit(X_train, y_train)

# Evaluate
print(classification_report(y_test, model.predict(X_test)))

# Save model and vectorizer
with open("model.pkl", "wb") as mf, open("vectorizer.pkl", "wb") as vf:
    pickle.dump(model, mf)
    pickle.dump(tfidf, vf)

print("✅ Trained and saved model + vectorizer!")
